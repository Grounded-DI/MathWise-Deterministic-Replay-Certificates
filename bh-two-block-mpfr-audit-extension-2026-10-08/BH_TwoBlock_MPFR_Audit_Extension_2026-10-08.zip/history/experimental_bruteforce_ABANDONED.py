#!/usr/bin/env python3
"""Generate directed-rounded MPFR witnesses for the two-block BH finite-grid proof.

Full interval arithmetic. Rational input constants. Writes exact threshold indices,
outward-rounded interval enclosures, and a machine-readable log.
Certificate construction is not the verifier: verify_certificate.py checks every
witness interval independently and verifies coverage and aggregate inequalities.
"""
import argparse
import hashlib
import json
import platform
import sys
import time
from fractions import Fraction
from pathlib import Path
from mpfr_interval import I, VERSION, PREC

PI0=Fraction(99,100)
PI1=Fraction(1,100)
GRID=1000
BINS=range(-500,500)

ROOT2=I.rat(2).sqrt()
S0ROOT2=I.rat(Fraction(4,3))
S1ROOT2=I.rat(Fraction(3,2)).sqrt()
HALF=I.rat(Fraction(1,2))
P0=I.rat(PI0)
P1=I.rat(PI1)
UPCACHE={}
MASSCACHE={}

def u_idx(j):
    if j not in UPCACHE:
        UPCACHE[j]=(I.rat(Fraction(j,1000))/ROOT2).erfc()
    return UPCACHE[j]

def Q_idx(j,a,sd):
    c=I.rat(Fraction(j,1000))
    ratio=S0ROOT2 if sd==0 else S1ROOT2
    a=I.rat(a)
    return (((c-a)/ratio).erfc()+((c+a)/ratio).erfc())*HALF

def abounds(k):
    zl=Fraction(k,100); zh=Fraction(k+1,100)
    v=[abs(zl),abs(zh)]
    amin=Fraction(0) if zl<=0<=zh else min(v)/3
    amax=max(v)/3
    # 15/4-z/2 is positive for every z in [-5,5]
    return amin, amax, Fraction(15,4)-zh/2, Fraction(15,4)-zl/2

def mass(k):
    if k not in MASSCACHE:
        zl=I.rat(Fraction(k,100))
        zh=I.rat(Fraction(k+1,100))
        MASSCACHE[k]=(((-zh)/ROOT2).erfc()-((-zl)/ROOT2).erfc())*HALF
    return MASSCACHE[k]

def upper(j,k,alpha):
    m0lo,m0hi,m1lo,m1hi=abounds(k)
    return P0*Q_idx(j,m0hi,0)+P1*Q_idx(j,m1hi,1)-u_idx(j+1)/I.rat(alpha)

def lower(j,k,alpha):
    m0lo,m0hi,m1lo,m1hi=abounds(k)
    return P0*Q_idx(j,m0lo,0)+P1*Q_idx(j,m1lo,1)-u_idx(j)/I.rat(alpha)

def find_start(ah):
    # Historical j starts preserved for a matched baseline comparison.
    if ah==Fraction(1,100): return 2575
    if ah==Fraction(501,50000): return 2573  # 0.01002
    return 2500

def verify_grid_start(j,alpha_hi):
    return (u_idx(j)-I.rat(alpha_hi)).gt0()

def make(label,alo,ahi,out,maxj=10000):
    start=time.monotonic()
    js=find_start(ahi)
    assert verify_grid_start(js,ahi), "start c does not cover alpha high"
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    rows=[]; neg_count=0; Uevals=0; Levals=0
    min_upper=None; min_lower=None
    coeff=I.rat(0)
    by_unit=[I.rat(0) for _ in range(10)]
    for k in BINS:
        # U negativity tested at hardest alpha: alpha_hi
        j=js
        while j<maxj:
            q=upper(j,k,ahi); Uevals+=1
            if not q.lt0():
                break
            neg_count+=1
            margin=-q
            if min_upper is None or margin.approx() < min_upper.approx():
                min_upper=margin
            j+=1
        else: raise RuntimeError(f"no upper threshold crossing k={k}")
        first_bad=j
        # L positivity tested at hardest alpha: alpha_lo
        ell=j
        while ell<maxj:
            q=lower(ell,k,alo); Levals+=1
            if q.gt0(): break
            ell+=1
        else: raise RuntimeError(f"no lower threshold feasibility k={k}")
        if not (u_idx(first_bad)-I.rat(alo)).lt0():
            raise RuntimeError(f"threshold upper bound w > alpha low at {k} {first_bad}")
        lmargin=q
        if min_lower is None or lmargin.approx()<min_lower.approx():
            min_lower=lmargin
        amin,amax,_,_=abounds(k)
        local_coeff=(P0*Q_idx(ell,amin,0))/u_idx(first_bad)
        contr=local_coeff*mass(k)
        coeff=coeff+contr
        unit=(k+500)//100
        by_unit[unit]=by_unit[unit]+contr
        rows.append({
            "k":k, "first_uncertified_upper_j":first_bad, "strict_lower_j":ell,
            "lower_sign_margin":lmargin.decimals(42),
            "local_coefficient":local_coeff.decimals(42),
            "latent_probability":mass(k).decimals(42),
            "weighted_coefficient":contr.decimals(42)
        })
        if (k+501)%200==0:
            print(f"{label}: {k+501}/1000 bins, U {Uevals}, L {Levals}",flush=True)
    res={
        "schema":"two-block-mpfr-certificate-v1",
        "label":label, "alpha_lo":str(alo), "alpha_hi":str(ahi),
        "alpha_lo_ratio":[alo.numerator,alo.denominator],
        "alpha_hi_ratio":[ahi.numerator,ahi.denominator],
        "precision_bits":PREC, "mpfr_version":VERSION,
        "source_pdf_sha256":"2def6e33d9a02eaaa1bc4b9b7b2d47818e32b15dd15ac85db0b0f56385076126",
        "j_start":js, "u_jstart_minus_alpha_hi":(u_idx(js)-I.rat(ahi)).decimals(52),
        "upper_evals":Uevals,"strict_upper_intervals":neg_count,"lower_evals":Levals,
        "minimum_strict_upper_margin":min_upper.decimals(52),
        "minimum_strict_lower_margin":min_lower.decimals(52),
        "coefficient_C":coeff.decimals(57),
        "point_FDR_bound_B":(coeff*I.rat(alo)).decimals(57) if alo==ahi else None,
        "by_unit_coefficient":[x.decimals(50) for x in by_unit],
        "rows":rows,
        "PASS":(coeff-I.rat(1)).gt0()
    }
    fname=out/(label+".json")
    fname.write_text(json.dumps(res,indent=2)+"\n")
    print("RESULT",label,"PASS",res["PASS"],"C",res["coefficient_C"],"B",res["point_FDR_bound_B"],
          "U",Uevals,"negative",neg_count,"L",Levals,
          "minimum sign margins",res["minimum_strict_upper_margin"],res["minimum_strict_lower_margin"],
          "secs",round(time.monotonic()-start,2),flush=True)
    return res

def parse_fraction(s):
    return Fraction(s)

if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--label",required=True)
    p.add_argument("--alpha-lo",required=True)
    p.add_argument("--alpha-hi",required=True)
    p.add_argument("--output-dir",default="results")
    args=p.parse_args()
    res=make(args.label,parse_fraction(args.alpha_lo),parse_fraction(args.alpha_hi),args.output_dir)
    sys.exit(0 if res["PASS"] else 2)
