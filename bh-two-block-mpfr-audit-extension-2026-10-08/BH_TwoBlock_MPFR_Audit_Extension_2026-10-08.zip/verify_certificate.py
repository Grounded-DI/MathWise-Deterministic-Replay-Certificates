#!/usr/bin/env python3
"""Independent certificate-witness verification with MPFR directed rounding.

Does not import the generator or trust PASS fields. Reconstructs conditional
Gaussian probabilities from standard deviations sqrt(8/9), sqrt(3/4).
Verifies every covering interval, endpoints, lengths, null weights, strict signs,
unit bin contributions, and global aggregate.
"""
import argparse,json,sys
from fractions import Fraction
from decimal import Decimal
from pathlib import Path
from mpfr_interval import I,VERSION,PREC,cmp

SQ2=I.rat(2).sqrt()
SD0=I.rat(Fraction(8,9)).sqrt()
SD1=I.rat(Fraction(3,4)).sqrt()
F0=I.rat(Fraction(99,100));F1=I.rat(Fraction(1,100))
def frac(s): return Fraction(Decimal(str(s)))
def ERFC_C(c):
    return (I.rat(Fraction(c,1000))/SQ2).erfc()
def Q_CHECK(j,a,g):
    # Independent arithmetic expression: Q = 1/2 sum erfc((c +/- a)/s_g/sqrt(2))
    c=I.rat(Fraction(j,1000))
    a=I.rat(a); s=SD0 if g==0 else SD1
    return (((c-a)/s/SQ2).erfc()+((c+a)/s/SQ2).erfc())/I.rat(2)
def MEANS(k):
    zl=Fraction(k,100); zh=Fraction(k+1,100)
    nulllo=Fraction(0) if zl<=0<=zh else min(abs(zl),abs(zh))/3
    nullhi=max(abs(zl),abs(zh))/3
    nonlo=Fraction(15,4)-zh/2
    nonhi=Fraction(15,4)-zl/2
    assert nonlo>0
    return nulllo,nullhi,nonlo,nonhi
def MASS(k):
    zl=I.rat(Fraction(k,100));zh=I.rat(Fraction(k+1,100))
    return (((-zh)/SQ2).erfc()-((-zl)/SQ2).erfc())/I.rat(2)
def SPAN_BOUND(k,left,right,alpha_hi):
    _,nhi,_,shi=MEANS(k)
    return (F0*Q_CHECK(left,nhi,0)+F1*Q_CHECK(left,shi,1)-
            ERFC_C(right)/I.rat(alpha_hi))
def FEASIBILITY(k,j,alpha_lo):
    nlo,_,slo,_=MEANS(k)
    return (F0*Q_CHECK(j,nlo,0)+F1*Q_CHECK(j,slo,1)-
            ERFC_C(j)/I.rat(alpha_lo))
def check(x,message):
    if not x: raise AssertionError(message)
def enclosure(v):
    check(isinstance(v,list) and len(v)==2,"enclosure malformed")
    l,r=frac(v[0]),frac(v[1])
    check(l<=r,"enclosure reversed -- rounding-direction failure")
    return l,r
def overlaps(v,computed,tag):
    a,b=enclosure(v)
    c,d=(frac(x) for x in computed.decimals(68))
    check(a<=d and c<=b,f"{tag} reported bound excludes recomputation")
def verify(file, require_violation=True):
    r=json.loads(Path(file).read_text())
    check(r.get("schema")=="two-block-mpfr-adaptive-v2","schema version")
    check(r.get("precision_bits")==PREC and r.get("mpfr_version")==VERSION,"environment mismatch")
    lo=Fraction(*r["alpha_lo_ratio"]);hi=Fraction(*r["alpha_hi_ratio"])
    check(0<lo<=hi<1,"incorrect alpha endpoint order")
    check(Fraction(r["alpha_lo"])==lo and Fraction(r["alpha_hi"])==hi,"alpha endpoint discrepancy")
    start=r["j_start"]
    check(isinstance(start,int) and start>=1,"bad jstart")
    check((ERFC_C(start)-I.rat(hi)).gt0(),"grid does not reach alpha_high")
    overlaps(r["covered_start_exceeds_alpha_high"],ERFC_C(start)-I.rat(hi),"start coverage")
    rows=r["rows"]
    check(len(rows)==1000 and [x.get("k") for x in rows]==list(range(-500,500)),"missing/duplicated/reordered latent bins")
    coeff=I.rat(0)
    units=[I.rat(0) for _ in range(10)]
    min_up=None;min_lo=None;covered=0
    for row in rows:
        k=row["k"];a=row["a"];b=row["b"]
        check(isinstance(a,int) and isinstance(b,int) and start<a<=b<10000,f"k {k} thresholds")
        check((ERFC_C(a)-I.rat(lo)).lt0(),f"k {k}: w exceeds alpha_low")
        intervals=row["intervals"]
        check(len(intervals)>0 and intervals[0][0]==start and intervals[-1][1]==a,f"k {k} uncovered threshold range")
        prev=start
        for left,right in intervals:
            check(isinstance(left,int) and isinstance(right,int),"non-integer grid")
            check(left==prev and left<right and right<=a,f"k {k} coverage gap/overlap")
            bound=SPAN_BOUND(k,left,right,hi)
            check(bound.lt0(),f"k {k}: strict upper sign FAIL [{left},{right}]")
            margin=-bound
            if min_up is None or cmp(margin.lo.ptr(),min_up.lo.ptr())<0:min_up=margin
            prev=right
            covered+=1
        check(prev==a,f"k {k} final cover mismatch")
        # Assert recorded a really is first elementary upper sign not provably negative.
        # Proof does not need this, but witness generation claims it.
        check(not SPAN_BOUND(k,a,a+1,hi).lt0(),f"k {k} recorded first sign fail inconsistent")
        feasibility=FEASIBILITY(k,b,lo)
        check(feasibility.gt0(),f"k {k}: strict lower sign FAIL b={b}")
        overlaps(row["lower_margin"],feasibility,f"lower margin k {k}")
        if min_lo is None or cmp(feasibility.lo.ptr(),min_lo.lo.ptr())<0:min_lo=feasibility
        nulllo,_,_,_=MEANS(k)
        term=(F0*Q_CHECK(b,nulllo,0)/ERFC_C(a))*MASS(k)
        overlaps(row["weighted_coefficient"],term,f"weighted coefficient bin {k}")
        coeff+=term
        units[(k+500)//100]+=term
        if (k+501)%200==0:
            print(f"VERIFY_PROGRESS {r['label']}: {k+501}/1000 bins, {covered} covering intervals",flush=True)
    check(covered==r["adaptive_covered_intervals"],"missing interval witness")
    overlaps(r["C_enclosure"],coeff,"aggregate C")
    overlaps(r["minimum_certified_upper_margin"],min_up,"minimum negative sign")
    overlaps(r["minimum_certified_lower_margin"],min_lo,"minimum positive sign")
    for i,t in enumerate(units): overlaps(r["per_unit_C_enclosures"][i],t,f"unit {i} coefficient")
    has_violation=(coeff-I.rat(1)).gt0()
    if require_violation:
        check(has_violation,"C not certified greater than 1")
    check(r["PASS_C_gt_1"]==has_violation,"generator pass/fail status inconsistent with independent calculation")
    if lo==hi:
        bound=coeff*I.rat(lo)
        overlaps(r["B_enclosure"],bound,"point lower FDR")
        check((bound-I.rat(lo)).gt0(),"point B not strictly above nominal")
    print(("VERIFIER_PASS" if has_violation else "VERIFIER_VALID_BUT_INSUFFICIENT") +" label="+r["label"]+" checked_cells="+str(covered)+" MPFR="+VERSION+
          " precision="+str(PREC)+" C="+str(coeff.decimals(62)),flush=True)
    return True
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("certificate")
    parser.add_argument("--allow-no-violation",action="store_true")
    args=parser.parse_args()
    try: verify(args.certificate, require_violation=not args.allow_no_violation)
    except Exception as e:
        print("VERIFIER_FAIL:",repr(e),file=sys.stderr)
        sys.exit(1)
