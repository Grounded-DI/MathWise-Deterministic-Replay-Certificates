#!/usr/bin/env python3
"""MPFR certified finite rectangle proof: adaptive interval coverings.

The only nonrigorous computation is a fast approximate suggestion of a,b.
The proof NEVER relies on those suggestions: it explicitly verifies a complete
coverage by MPFR outward-rounded upper bounds, a strict lower witness, and
the full aggregate. All accepted coverings saved for independent checking.

MPFR C library via ctypes. No python-flint or original source required.
"""
from __future__ import annotations
import argparse,json,math,sys,time
from pathlib import Path
from fractions import Fraction
from mpfr_interval import I,VERSION,PREC

PI0=Fraction(99,100); PI1=Fraction(1,100)
P0=I.rat(PI0); P1=I.rat(PI1)
ROOT2=I.rat(2).sqrt()
SQ0=I.rat(Fraction(4,3)) # sqrt(8/9) * sqrt(2) = 4/3
SQ1=I.rat(Fraction(3,2)).sqrt()
HALF=I.rat(Fraction(1,2))
UPCACHE={}; MASSCACHE={}; METRICS={"interval_bounds":0,"candidate_checks":0}
def u(j):
    if j not in UPCACHE: UPCACHE[j]=(I.rat(Fraction(j,1000))/ROOT2).erfc()
    return UPCACHE[j]
def Q(j,a,sd):
    c=I.rat(Fraction(j,1000))
    aa=I.rat(a); sq=SQ0 if sd==0 else SQ1
    return (((c-aa)/sq).erfc()+((c+aa)/sq).erfc())*HALF
def amps(k):
    zl=Fraction(k,100); zh=Fraction(k+1,100)
    return (Fraction(0) if zl<=0<=zh else min(abs(zl),abs(zh))/3,
            max(abs(zl),abs(zh))/3,
            Fraction(15,4)-zh/2,
            Fraction(15,4)-zl/2)
def mass(k):
    if k not in MASSCACHE:
        zl=I.rat(Fraction(k,100)); zh=I.rat(Fraction(k+1,100))
        MASSCACHE[k]=(((-zh)/ROOT2).erfc()-((-zl)/ROOT2).erfc())*HALF
    return MASSCACHE[k]
def sign_upper_span(j0,j1,k,hi):
    # Proves Gz(u(c))-u(c)/alpha < 0 for every z in bin, c in [j0/1000,j1/1000].
    # Q decreases in c; u(c)/alpha decreases in c.
    METRICS["interval_bounds"]+=1
    mn0,mx0,mn1,mx1=amps(k)
    return (P0*Q(j0,mx0,0)+P1*Q(j0,mx1,1)-u(j1)/I.rat(hi))
def lower(j,k,lo):
    METRICS["candidate_checks"]+=1
    mn0,mx0,mn1,mx1=amps(k)
    return (P0*Q(j,mn0,0)+P1*Q(j,mn1,1)-u(j)/I.rat(lo))
def floatq(c,a,sd):
    sq=4/3 if sd==0 else math.sqrt(1.5)
    return .5*(math.erfc((c-a)/sq)+math.erfc((c+a)/sq))
def floatu(c):
    return math.erfc(c/math.sqrt(2))
def hints(k,jstart,lo,hi):
    mn0,mx0,mn1,mx1=amps(k)
    upint=hi.numerator/hi.denominator
    lowint=lo.numerator/lo.denominator
    a=None
    for j in range(jstart,10000):
        c=j/1000
        v=.99*floatq(c,float(mx0),0)+.01*floatq(c,float(mx1),1)-floatu((j+1)/1000)/upint
        if v>=0:
            a=j;break
    if a is None: raise RuntimeError(f"no floating threshold hint k={k}")
    b=None
    for j in range(a,10000):
        c=j/1000
        v=.99*floatq(c,float(mn0),0)+.01*floatq(c,float(mn1),1)-floatu(c)/lowint
        if v>0:
            b=j;break
    if b is None: raise RuntimeError(f"no floating lower hint k={k}")
    return a,b
def first_indices(k,jstart,lo,hi):
    a,b=hints(k,jstart,lo,hi)
    # Exact verification near float candidates; numerical hint never proves anything.
    while a>jstart and not sign_upper_span(a-1,a,k,hi).lt0():
        a-=1
    while sign_upper_span(a,a+1,k,hi).lt0():
        a+=1
    while not lower(b,k,lo).gt0():
        b+=1
    while b>a and lower(b-1,k,lo).gt0():
        b-=1
    if b<a: b=a
    if not lower(b,k,lo).gt0():
        raise RuntimeError(f"cannot certify lower bound k={k}")
    return a,b
def cover(k,start,stop,hi):
    # Complete, disjoint partition of [start,stop] into certified c-intervals.
    todo=[(start,stop)]
    accepted=[]; smallest=None
    while todo:
        left,right=todo.pop()
        if not left<right: raise AssertionError("invalid subdivision")
        q=sign_upper_span(left,right,k,hi)
        if q.lt0():
            accepted.append((left,right))
            mg=-q
            if smallest is None or mg.approx()<smallest.approx(): smallest=mg
        else:
            if right-left==1:
                raise RuntimeError(f"uncertified elementary interval k={k} [{left},{right}]")
            mid=(left+right)//2
            todo.append((mid,right))
            todo.append((left,mid))
    accepted.sort()
    if accepted[0][0]!=start or accepted[-1][1]!=stop:
        raise AssertionError("domain not fully covered")
    if any(accepted[i][1]!=accepted[i+1][0] for i in range(len(accepted)-1)):
        raise AssertionError("gap/overlap in covering")
    return accepted,smallest

def run(label,lo,hi,outdir):
    start=time.monotonic()
    jstart=2575 if lo==hi==Fraction(1,100) else (2573 if lo==Fraction(499,50000) and hi==Fraction(501,50000) else 2500)
    assert (u(jstart)-I.rat(hi)).gt0(), "starting c does not reach alpha high"
    rows=[]; coeff=I.rat(0); unit=[I.rat(0) for _ in range(10)]
    min_upper=None; min_lower=None; numcover=0;amin_all=[];bmin_all=[]
    for k in range(-500,500):
        a,b=first_indices(k,jstart,lo,hi)
        assert (u(a)-I.rat(lo)).lt0(),f"w>alpha_lo {k}"
        accepted,mu=cover(k,jstart,a,hi)
        numcover+=len(accepted)
        amin_all.append(a); bmin_all.append(b)
        if min_upper is None or mu.approx()<min_upper.approx(): min_upper=mu
        ml=lower(b,k,lo)
        assert ml.gt0(),f"lower sign failed k={k}"
        if min_lower is None or ml.approx()<min_lower.approx(): min_lower=ml
        mn0,_,_,_=amps(k)
        local=P0*Q(b,mn0,0)/u(a)
        m=mass(k)
        weighted=local*m
        coeff=coeff+weighted
        unit[(k+500)//100]+=weighted
        rows.append({"k":k,"a":a,"b":b,
                     "intervals":accepted,
                     "lower_margin":ml.decimals(46),
                     "weighted_coefficient":weighted.decimals(50)})
        if (k+501)%200==0:
            print(f"PROGRESS {label}: {k+501}/1000 bins, certified cover intervals={numcover}, MPFR bounds={METRICS['interval_bounds']}",flush=True)
    point=lo==hi
    result={
        "schema":"two-block-mpfr-adaptive-v2",
        "label":label,"alpha_lo":str(lo),"alpha_hi":str(hi),
        "alpha_lo_ratio":[lo.numerator,lo.denominator],
        "alpha_hi_ratio":[hi.numerator,hi.denominator],
        "precision_bits":PREC,"mpfr_version":VERSION,
        "j_start":jstart,"covered_start_exceeds_alpha_high":(u(jstart)-I.rat(hi)).decimals(55),
        "min_first_uncertified_j":min(amin_all),"max_first_uncertified_j":max(amin_all),
        "min_lower_j":min(bmin_all),"max_lower_j":max(bmin_all),
        "adaptive_covered_intervals":numcover,
        "mpfr_interval_calls":METRICS["interval_bounds"],
        "mpfr_candidate_lower_checks":METRICS["candidate_checks"],
        "minimum_certified_upper_margin":min_upper.decimals(55),
        "minimum_certified_lower_margin":min_lower.decimals(55),
        "C_enclosure":coeff.decimals(62),
        "B_enclosure":(coeff*I.rat(lo)).decimals(62) if point else None,
        "per_unit_C_enclosures":[v.decimals(52) for v in unit],
        "PASS_C_gt_1":(coeff-I.rat(1)).gt0(),
        "rows":rows,
        "elapsed_wall_seconds":round(time.monotonic()-start,3)
    }
    outdir=Path(outdir);outdir.mkdir(exist_ok=True,parents=True)
    filename=outdir/(label+".json")
    filename.write_text(json.dumps(result,indent=1)+"\n")
    print("RESULT",label,"PASS",result["PASS_C_gt_1"],"C",result["C_enclosure"],
          "B",result["B_enclosure"],"covered_intervals",numcover,"calls",METRICS["interval_bounds"],
          "min margins",result["minimum_certified_upper_margin"],result["minimum_certified_lower_margin"],
          "seconds",result["elapsed_wall_seconds"],flush=True)
    return result
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--label",required=True)
    parser.add_argument("--alpha-lo",required=True)
    parser.add_argument("--alpha-hi",required=True)
    parser.add_argument("--output-dir",default="results")
    args=parser.parse_args()
    r=run(args.label,Fraction(args.alpha_lo),Fraction(args.alpha_hi),args.output_dir)
    sys.exit(0 if r["PASS_C_gt_1"] else 2)
