# Original point-certificate unit-bin comparison

The draft's §6 printed decimals are truncated; this comparison does not mistake those printed decimals for exact interval enclosures. Full certified enclosures are retained in `../results/point_001.json`.

| Z range | Draft printed contribution | Independent certified lower endpoint | Agreement within 1e-21 |
|---|---:|---:|:---:|
| [-5, -4] | 0.0000115641299609205509669 | 0.00001156412996092055096692707 | YES |
| [-4, -3] | 0.0001910406736692213611250 | 0.00019104067366922136112500498 | YES |
| [-3, -2] | 0.0010372328000280610818103 | 0.00103723280002806108181036234 | YES |
| [-2, -1] | 0.0019770493938734550768221 | 0.00197704939387345507682211124 | YES |
| [-1, 0] | 0.0015473902811503407120878 | 0.00154739028115034071208782292 | YES |
| [0, 1] | 0.0014207003268786251786284 | 0.00142070032687862517862841808 | YES |
| [1, 2] | 0.0019179247950068331737665 | 0.00191792479500683317376655255 | YES |
| [2, 3] | 0.0015063175588749091913413 | 0.00150631755887490919134127752 | YES |
| [3, 4] | 0.0005183429146171462370210 | 0.00051834291461714623702104003 | YES |
| [4, 5] | 0.0000279697905586167489979 | 0.00002796979055861674899786555 | YES |

All ten printed unit-bin contributions agree with the independent MPFR calculation to the displayed precision, allowing the draft's rounding/truncation.
