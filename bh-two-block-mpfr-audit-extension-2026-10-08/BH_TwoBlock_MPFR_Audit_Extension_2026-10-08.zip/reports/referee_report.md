# Independent referee-style mathematical and computational audit
**Date:** October 8, 2026
**Primary artifact:** _A Two-Block Counterexample for the Benjamini–Hochberg Procedure under Correlated Two-Sided Gaussian Tests_ (private technical draft, July 15, 2026).
**Basis:** Original seven-page PDF retained byte-for-byte with SHA-256 `2def6e33d9a02eaaa1bc4b9b7b2d47818e32b15dd15ac85db0b0f56385076126`.
**Final internal computational disposition:** GREEN for this reproducible MPFR evidence package, subject to external peer/third-party review and correct descriptions of scope.
**Research classification:** NEW CERTIFIED EXTENSION (wider alpha interval for the same model); not a new first disproof of BH control.
**Widest interval certified in this execution:** [0.00990, 0.01010], piecewise certificates.

## 1. Mathematical model and provenance

For each N there are 99N true nulls with Gaussian statistics X^(0)=Z/3+(2sqrt(2)/3)epsilon, and N nonnulls X^(1)=15/4-Z/2+(sqrt(3)/2)eta. All latent and residual normal variables are mutually independent. Marginal two-sided p-values are p=2*(1-Phi(|X|)). The covariance is a a^T + D where the factor loadings are 1/3 and -1/2, and diagonal residual variances 8/9 and 3/4. Thus it is positive definite; marginal variances are exactly one. Within-null, within-signal and cross-block correlations are 1/9, 1/4 and -1/6. The null p-values are marginal Uniform(0,1).

The uploaded PDF is a private technical record with authorship withheld; this computational audit does not assign or transfer authorship. Edgar Dobriban's three-block original paper (arXiv:2607.12208, submitted July 13, 2026) is the prior motivating disproof. The present work is a simpler one-null/one-signal block example with an extended alpha interval and newly executable certificate evidence. The original preprint proves a numerically larger FDR violation at alpha 0.01. Its published article and related work must be acknowledged, not superseded.

Source: https://arxiv.org/abs/2607.12208 ; original public code: https://github.com/dobriban/BH

## 2. Adversarial mathematical review — ten requested gates

1. **Positive definite model:** PASS. D is strictly positive diagonal, so a a^T + D is positive definite; diag equals 1.
2. **Gaussian conditional law:** PASS. Given Z=z, the true-null mean is z/3, residual variance 8/9; the signal mean is 15/4-z/2, residual variance 3/4.
3. **Empirical-process convergence:** PASS. Conditional blockwise i.i.d. samples satisfy Glivenko–Cantelli; unconditional a.s. follows by integrating regular conditional probabilities. Continuity follows from strictly positive residual variances.
4. **BH grid representation:** PASS, with an exposition clarification. For maximal feasible r the number of p-values <= alpha r/(100N) equals r; otherwise r+1 is feasible. Hence R_N=100N*tau_N/alpha whenever tau_N>0.
5. **Two strict-sign lemmas:** PASS. Uniform convergence carries the compact upper sign and the strict feasible point; the FDP lower bound then follows by bracket limits and monotonicity.
6. **Full threshold coverage:** PASS. Certificate starts at j0 and proves u(j0/1000)>alpha_high. The accepted MPFR-certified subintervals tile [j0/1000,a_k/1000] exactly, with no gaps. Because u decreases, this covers all p-thresholds [u(a_k/1000),alpha] in the BH domain.
7. **Latent-bin rectangle construction:** PASS. Exactly 1,000 adjacent k/100 to (k+1)/100 bins cover [-5,5]. Absolute conditional means are bounded by exact rationals; for signal mean 15/4-z/2 positivity holds on [-5,5].
8. **Alpha endpoint argument:** PASS. The upper infeasibility bound is hardest at alpha_high, lower feasibility at alpha_low. Separate certified subintervals are allowed; no inference from sampled alpha points is used.
9. **Fatou passage:** PASS. FDP_N is in [0,1] and has a conditional almost-sure liminf bound on each bin. Taking expectations and omitting |Z|>5 is valid because omitted contributions are nonnegative.
10. **Asymptotic quantifiers:** PASS. The result is pointwise for each fixed alpha; neither an explicit finite N0 nor a common N0 uniform across alpha is supplied.

**Exposition items, not discovered counterexamples to the proof:** The original note should state the initial grid-coverage check explicitly, explain the BH rejection count identity, and distinguish uniform alpha coverage of the numerical certificate from a uniform finite-N threshold. The uploaded file has not been overwritten.

## 3. Certified computations and failed attempts

All numbers below are conservative decimal *lower endpoints* of directed MPFR interval enclosures. A coefficient greater than one yields a valid FDR lower bound alpha*C for each fixed alpha in the corresponding range.

| Certificate | Alpha segment | Lower endpoint of C | Certificate inference | Accepted upper-cover intervals |
|---|---|---:|---|---:|
| point_001 | 0.01000 – 0.01000 | 1.01555326646181293 | PASS | 24,041 |
| baseline_alpha | 0.00998 – 0.01002 | 1.00444096942730566 | PASS | 24,016 |
| extend_00995_01005 | 0.00995 – 0.01005 | 0.98845111473428278 | INSUFFICIENT | 24,063 |
| refined_left_00995_01000 | 0.00995 – 0.01000 | 1.00174306093767050 | PASS | 24,134 |
| refined_right_01000_01005 | 0.01000 – 0.01005 | 1.00183796517458533 | PASS | 24,063 |
| extend_00990_01010 | 0.00990 – 0.01010 | 0.96311735671209936 | INSUFFICIENT | 24,022 |
| outer_left_00990_00995 | 0.00990 – 0.00995 | 1.00156625721056118 | PASS | 24,158 |
| outer_right_01005_01010 | 0.01005 – 0.01010 | 1.00200415573120195 | PASS | 24,022 |

The direct, unsplit outer-range trials yield strictly positive numerical values but **C < 1**; these are failed lower-bound attempts, NOT proofs that BH controls FDR on those ranges. The allowed finite refinement partitions the requested ranges into smaller alpha intervals and reuses independently verified middle segments. Each successful interval has a completely checked MPFR witness.

**Overall certified theorem:**
For every fixed alpha in **[0.00990, 0.01010]**, liminf_(N→infinity) FDR_(N,alpha) >= alpha*C_* where C_* > **1.0015662572105611** > 1. Brackets may differ by alpha subinterval. Each fixed alpha admits some (not explicitly calculated) N0(alpha) beyond which FDR_(N,alpha)>alpha.

The original result is restricted to [0.00998,0.01002], width 0.00004. The new widest certified interval has width 0.00020, or 5.00 times the original width.

## 4. Numerical verification methodology

- Binary MPFR 4.2.2 with 256-bit directed rounding (RNDD/RNDU); no simulated confidence intervals are used as proof.
- Every rationals-only parameter and grid location is evaluated through exact numerator/denominator conversion before rounded MPFR operations.
- Gaussian tails use MPFR correctly rounded erfc. All arithmetic operations retain lower/upper interval endpoints.
- A floating-point math.erfc scan proposes a and b indices, but it has no proof status. Every accepted range and lower feasible point is independently certified with MPFR; failure to certify blocks the output.
- Adaptive subdivision replaces a slow per-cell scan: for an interval of c it upper-bounds both Gaussian tails at the *left* end and -u(c)/alpha at the *right* end. This is valid by monotonicity and covers all intervening c continuously.
- The separately implemented verifier recomputes all intervals with a different Gaussian expression (separate residual standard deviation and sqrt(2) divisions), independently validates index coverage and signs, and recomputes each weighted coefficient and its 10 Gaussian unit-bin aggregates. The generator and verifier share the low-level MPFR wrapper: this is independent checking of certificate logic, not independent software-library implementation or third-party peer review.
- Seven deliberately corrupted certificates are rejected (missing bin; reversed alpha endpoints; missing cover; missing threshold scope; reversed declared interval endpoints; fabricated weighted term; and an overwide rectangle with a false strict sign).
- The program separately verifies the cosmetic starting-index discrepancy 2573/2575 for all 1,000 bins and both stated alpha levels, 2,000 elementary intervals per level.

**Count reconciliation:** The original point run's 24,041 accepted covering intervals require 47,082 recursive interval evaluations (= 2*24,041-1,000), plus 2,000 local boundary probes, for 49,082 recorded MPFR interval-bound calls. The previously mentioned 17,175-witness optimization is NOT demonstrated by the retained artifacts and is not used in this release.

## 5. Limitations and unsolved gates

- Original Arb source files and their five historical SHA-256 digests were not provided, so hashes and original source reproduction remain **UNVERIFIED**. The attached evidence is a *new MPFR reconstruction*, not a rerun of historical Arb code.
- No explicit finite N0(alpha) or uniform N0 exists in this package; their absence is a scope limit, not a discovered contradiction.
- No optimization of the Gaussian parameters or larger-violation claim was attempted beyond the stated bounded alpha test. Dobriban's original three-block bound at alpha 0.01 remains numerically larger.
- Public GitHub repository claims and missing evidence files must be updated by the owner before claiming this certificate is publicly independently executable.
- Byte hashes show exact file integrity only. No formal Lean proof, universal determinism, professional peer-review verdict, mathematical priority determination, or external endorsement is claimed.
- An external statistician can now independently run the included code and challenge any strict inequality or quantified statement; that external check has not yet occurred.

## 6. Release and communication recommendation

**Artifact internal release:** GREEN, contingent on package manifest/ZIP verification shown in SHA256SUMS and execution receipts.

**Public repository currently:** AMBER until this package is uploaded and the README distinguishes historical Arb claims from newly executed MPFR evidence.

**Scientific outcome:** NEW CERTIFIED EXTENSION of the alpha interval; exact widest span = [0.00990, 0.01010], without changing the two-block model.

**Communication:** The attached unsent follow-up may be sent only after the operator reviews the package, verifies the SHA-256 manifest and makes the evidence accessible by a stable link. A request for external mathematical criticism is appropriate. Avoid presenting this as Dobriban's endorsement or a stronger violation than his reported examples.
