Subject: Two-block BH note — independently reproducible certificate and a wider alpha interval

Hi Edgar,

I wanted to share one substantive follow-up to the two-block BH note I sent in July. I preserved the same 99:1 null/signal Gaussian model and built a fresh outward-rounded 256-bit MPFR certificate package, with separately implemented witness verification and machine-readable outputs.

The original point bound was reproduced, and the same model now has a piecewise certified violation for every fixed alpha in [0.00990, 0.01010]. The conservative uniform coefficient is C > 1.0015662572105611; the improvement is a wider range of nominal levels, not a larger violation at alpha = 0.01 or a claim to displace your original three-block result.

The package includes the verifier, strict-sign witnesses, full logs, and SHA-256 manifest. [INSERT A STABLE, CHECKED REPOSITORY OR ARCHIVE LINK.]

If you have time to scrutinize the argument or spot a weakness in the certificates, I'd value your technical assessment. No pressure at all, and congratulations on the broader work.

Best,
Mark

UNSENT DRAFT — operator review and archive upload required before use.
