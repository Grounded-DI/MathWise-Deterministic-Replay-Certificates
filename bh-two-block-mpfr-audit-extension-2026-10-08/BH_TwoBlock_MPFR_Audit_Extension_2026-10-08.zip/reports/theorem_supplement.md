# Two-block BH counterexample: certified alpha-interval extension
**Technical supplement, October 8, 2026.** This file supplements but never modifies the unchanged July 15, 2026 private technical draft.

## Theorem (wider nominal-level interval, fixed Gaussian model)

Let Z, epsilon_i and eta_j be independent standard normal variables. For each positive integer N form 100N statistics:
- X_i^(0) = Z/3 + (2 sqrt(2)/3)epsilon_i, i=1,...,99N (true nulls);
- X_j^(1) = 15/4 - Z/2 + (sqrt(3)/2)eta_j, j=1,...,N (nonnulls).

Construct marginal two-sided standard normal p-values and apply ordinary Benjamini–Hochberg at nominal level alpha.

For every *fixed* alpha in **[0.00990, 0.01010]**,
liminf_(N→infinity) FDR_(N,alpha) >= alpha C_*,
where the provided, independently verified 256-bit MPFR certificates establish **C_* > 1.0015662572105611 > 1**.

Thus for each fixed such alpha there is an N0(alpha) with FDR_(N,alpha)>alpha for every N>=N0(alpha). No common finite N0 is asserted.

## Exact alpha partition and coefficient enclosures

| Closed alpha interval | Rigorous coefficient C lower bound (truncated downward) |
|---|---:|
| [0.00990, 0.00995] | 1.001566257210561185 |
| [0.00995, 0.01000] | 1.001743060937670504 |
| [0.01000, 0.01005] | 1.001837965174585330 |
| [0.01005, 0.01010] | 1.002004155731201950 |

## Argument

Write u(c)=erfc(c/sqrt(2))=2 barPhi(c) and Q(c;a,s)=barPhi((c-a)/s)+barPhi((c+a)/s).
Conditional on Z=z, the two-block limiting p-value distribution at u(c) is
G_z(u(c)) = (99/100)Q(c;|z|/3,sqrt(8/9)) +(1/100)Q(c;15/4-z/2,sqrt(3/4)).

For k=-500,...,499, let B_k=[k/100,(k+1)/100]. Each witness records integers a_k,b_k with a_k<=b_k and finite subintervals partitioning [j0,a_k]. The MPFR verifier establishes:
(a) u(j0/1000)>alpha_high and u(a_k/1000)<alpha_low;
(b) G_z(u(c))-u(c)/alpha<0 simultaneously for all z in B_k and all c∈[j0/1000,a_k/1000], for every alpha in the relevant alpha segment;
(c) G_z(u(b_k/1000))>u(b_k/1000)/alpha for every z in B_k and every alpha in the segment.

In (b) upper infeasibility is checked at alpha_high using Gaussian-tail bounds at the left c endpoint and u(c) at the right endpoint. In (c) feasibility is checked at alpha_low using the minimum absolute means over B_k. Gaussian Q decreases in c and increases in the absolute mean, ensuring each result uniformly covers its rectangle.

Therefore the standard BH threshold bracketing lemmas give, conditional on Z∈B_k,
liminf_(N→infinity) FDP_(N,alpha) >= alpha*(99/100)*Q(b_k/1000;m0min_k,sqrt(8/9))/u(a_k/1000).

Taking expectations and applying Fatou yields
liminf_(N→infinity) FDR_(N,alpha) >= alpha*C_s
for each fixed alpha in segment s, with C_s equal to the certified finite normal-bin weighted sum. The minimum verified coefficient across all listed segments is C_*. This proves the theorem.

**Novelty limit:** the Gaussian model is unchanged; the advancement is a wider rigorously certified alpha interval by piecewise threshold bracketing and a new reproducibility package. It is not a new disproof of the general conjecture or a larger FDR violation at alpha=0.01.

**Reproduction:** see ../README.md and ../results/*.json and ../logs/verify_*.log.
