# Two-block BH counterexample — independently reproducible MPFR audit

This archive contains a **new MPFR reconstruction**, executable certificate witnesses, and a separately written verifier for the July 15, 2026 two-block BH technical note. The source PDF is preserved **byte-identically** as `original/Two_Block_BH_Private_Technical_Draft.pdf`. The historical Arb certificate source programs were unavailable and their historical digests are NOT asserted to match.

## Verified result and limits

- At alpha=0.01, the finite certified FDR lower bound reproduces 0.010155532664618129... > 0.01.
- The original interval [0.00998, 0.01002] is independently reproduced.
- A **new wider interval [0.00990, 0.01010]** is rigorously certified for every fixed alpha by segment-wise MPFR witnesses, with coefficient C_* > 1.0015662572105611 >1.
- The guarantee is asymptotic for each fixed alpha, not a finite-N bound or a uniform finite-N0.
- An entire proposed interval may fail as a *single* certificate even when a partition into subintervals succeeds. Trials explicitly marked INSUFFICIENT are retained as negative findings.

## Reproduce on Linux

Required: Python 3.13.5, shared library `libmpfr.so.6` (executed version MPFR 4.2.2). All execution code is Python standard library; no Python package installation is needed. For an external machine, install the system MPFR development/runtime package matching your OS. The tool uses ctypes to bind MPFR.

First verify byte hashes after extracting:
```sh
python verify_release.py
```

Independently verify the original and the new proof components:
```sh
python verify_certificate.py results/point_001.json
python verify_certificate.py results/baseline_alpha.json
python verify_certificate.py results/refined_left_00995_01000.json
python verify_certificate.py results/refined_right_01000_01005.json
python verify_certificate.py results/outer_left_00990_00995.json
python verify_certificate.py results/outer_right_01005_01010.json
```

Check genuine failed unsplit trials without mislabeling them successes:
```sh
python verify_certificate.py results/extend_00995_01005.json --allow-no-violation
python verify_certificate.py results/extend_00990_01010.json --allow-no-violation
```

Run adversarial corruption tests and initial grid-index reconciliation:
```sh
python test_mutations.py results/point_001.json
python verify_start_discrepancy.py
```

Regenerate examples (each completed job normally requires computation):
```sh
python generate_certificate.py --label point_001 --alpha-lo 0.01 --alpha-hi 0.01 --output-dir results
python generate_certificate.py --label baseline_alpha --alpha-lo 0.00998 --alpha-hi 0.01002 --output-dir results
python generate_certificate.py --label refined_left_00995_01000 --alpha-lo 0.00995 --alpha-hi 0.01000 --output-dir results
python generate_certificate.py --label refined_right_01000_01005 --alpha-lo 0.01000 --alpha-hi 0.01005 --output-dir results
python generate_certificate.py --label outer_left_00990_00995 --alpha-lo 0.00990 --alpha-hi 0.00995 --output-dir results
python generate_certificate.py --label outer_right_01005_01010 --alpha-lo 0.01005 --alpha-hi 0.01010 --output-dir results
```

After regeneration, SHA manifest hashes change if serialization/runtime formatting differs; matching mathematical output is not the same as byte identity. To preserve this archive's original witness hashes, execute the regeneration into another directory and compare numerically rather than overwriting the verified package.

## Certificate files

- `results/point_001.json` — verifier PASS
- `results/baseline_alpha.json` — verifier PASS
- `results/extend_00995_01005.json` — valid interval witness, C<1
- `results/refined_left_00995_01000.json` — verifier PASS
- `results/refined_right_01000_01005.json` — verifier PASS
- `results/extend_00990_01010.json` — valid interval witness, C<1
- `results/outer_left_00990_00995.json` — verifier PASS
- `results/outer_right_01005_01010.json` — verifier PASS

`results/*.json` contain exact rational alpha endpoints, all 1,000 latent-bin witness records, interval partitions tiling each full c-range, outward-rounded local signs and weighted coefficients, aggregate enclosures, and MPFR execution settings.

`logs/` contains complete stdout/stderr from the executions, including the expected explicit “VALID_BUT_INSUFFICIENT” verdicts on unsuccessful global-bracket trials. Startup diagnostics from an unrelated host spreadsheet warmup are preserved in the raw logs; they did not change the certificate exit results.

`reports/referee_report.md` is the technical review and correct-scope analysis. `reports/theorem_supplement.md` is the strengthened statement and proof outline. `reports/email_UNSENT.md` is a review-only draft; no communication has been sent.

## Research integrity

No original Arb source file or historic SHA digest was independently authenticated. The new verifier shares the correctly rounded MPFR arithmetic wrapper but independently recomputes every mathematical witness using distinct conditional Gaussian code. This is **not** a formal proof in Lean, an external referee report, or third-party independent certification. The original three-block work of Edgar Dobriban (arXiv:2607.12208) remains prior work. Cryptographic hashes prove file identity, not theorem truth or research priority.

All results are supplied for independent challenge and mathematical scrutiny.
