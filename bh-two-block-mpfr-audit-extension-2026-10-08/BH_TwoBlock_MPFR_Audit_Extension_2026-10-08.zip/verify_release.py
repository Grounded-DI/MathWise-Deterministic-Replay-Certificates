#!/usr/bin/env python3
"""Verify every SHA-256 entry against the extracted package; manifest excludes itself."""
import hashlib,sys
from pathlib import Path
def main():
    root=Path(__file__).resolve().parent
    manifest=root/"SHA256SUMS.txt"
    n=0
    for line in manifest.read_text().splitlines():
        if not line.strip(): continue
        expected,relative=line.split("  ",1)
        f=root/relative
        assert f.is_file(),f"missing {relative}"
        actual=hashlib.sha256(f.read_bytes()).hexdigest()
        assert actual==expected,f"hash mismatch: {relative}"
        n+=1
    print("SHA256_MANIFEST_PASS",n,"files",flush=True)
if __name__=="__main__":main()
