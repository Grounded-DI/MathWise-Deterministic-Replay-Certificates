"""Correctly directed-rounded binary MPFR intervals, via system libmpfr.
No mpmath, Python floats, or MPFR default-rounding results are used for certificates.
Fractions are passed as exact integers to mpfr_div. erfc is MPFR correctly rounded.
"""
from __future__ import annotations
import ctypes as C
import ctypes.util
from fractions import Fraction

DLL = ctypes.util.find_library("mpfr")
if not DLL:
    raise RuntimeError("libmpfr not available; no rigorous certificate can run")
M = C.CDLL(DLL)
RNDD=3
RNDU=2
PREC=256

class Struct(C.Structure):
    _fields_=[("prec",C.c_long),("sign",C.c_int),("exp",C.c_long),("d",C.c_void_p)]
P=C.POINTER(Struct)
def bind(name,args,restype=C.c_int):
    f=getattr(M, "mpfr_"+name)
    f.argtypes=args
    f.restype=restype
    return f

init=bind("init2",[P,C.c_long],None)
clear=bind("clear",[P],None)
seti=bind("set_si",[P,C.c_long,C.c_int])
sets=bind("set_str",[P,C.c_char_p,C.c_int,C.c_int])
add=bind("add",[P,P,P,C.c_int])
sub=bind("sub",[P,P,P,C.c_int])
mul=bind("mul",[P,P,P,C.c_int])
div=bind("div",[P,P,P,C.c_int])
sqr=bind("sqrt",[P,P,C.c_int])
erfcomp=bind("erfc",[P,P,C.c_int])
neg=bind("neg",[P,P,C.c_int])
cmp=bind("cmp",[P,P])
getd=bind("get_d",[P,C.c_int],C.c_double)
getstr=bind("get_str",[C.c_void_p,C.POINTER(C.c_long),C.c_int,C.c_size_t,P,C.c_int],C.c_void_p)
freestr=bind("free_str",[C.c_void_p],None)
getversion=bind("get_version",[],C.c_char_p)
VERSION=getversion().decode()

class MP:
    __slots__=("s",)
    def __init__(self,number=None,rnd=RNDD):
        self.s=Struct()
        init(C.byref(self.s),PREC)
        if number is not None:
            r=sets(C.byref(self.s),str(int(number)).encode(),10,rnd)
            if r != 0:  # exact small integer only
                raise RuntimeError("non-exact integer: "+str(number))
    def __del__(self):
        if hasattr(self,"s"):
            clear(C.byref(self.s))
    def ptr(self):
        return C.byref(self.s)
    def dec(self,rounding=RNDD,digits=65):
        ex=C.c_long(0)
        p=getstr(None,C.byref(ex),10,digits,self.ptr(),rounding)
        if not p: raise MemoryError("mpfr_get_str")
        ss=C.string_at(p).decode()
        freestr(p)
        sg="-" if ss.startswith("-") else ""
        mant=ss.lstrip("-")
        return sg+mant[0]+"."+mant[1:]+"e"+str(ex.value-1)
    def fl(self):
        return getd(self.ptr(),RNDD)

def op2(f,x,y,rnd):
    r=MP()
    f(r.ptr(),x.ptr(),y.ptr(),rnd)
    return r

def op1(f,x,rnd):
    r=MP()
    f(r.ptr(),x.ptr(),rnd)
    return r

def sort(vals,choose_max):
    winner=vals[0]
    for t in vals[1:]:
        order=cmp(t.ptr(),winner.ptr())
        if (order>0 if choose_max else order<0): winner=t
    return winner

class I:
    __slots__=("lo","hi")
    def __init__(self,lo,hi=None):
        if isinstance(lo,MP):
            self.lo=lo; self.hi=hi if hi is not None else lo
        else:
            other=I.rat(lo)
            self.lo=other.lo; self.hi=other.hi
    @staticmethod
    def rat(q):
        f=Fraction(q)
        n=MP(f.numerator); d=MP(f.denominator)
        return I(op2(div,n,d,RNDD),op2(div,n,d,RNDU))
    def __add__(self,y):
        y=lift(y)
        return I(op2(add,self.lo,y.lo,RNDD),op2(add,self.hi,y.hi,RNDU))
    __radd__=__add__
    def __neg__(self):
        return I(op1(neg,self.hi,RNDD),op1(neg,self.lo,RNDU))
    def __sub__(self,y):
        return self+(-lift(y))
    def __rsub__(self,y):
        return lift(y)+(-self)
    def __mul__(self,y):
        y=lift(y)
        candlo=[op2(mul,x,z,RNDD) for x in (self.lo,self.hi) for z in (y.lo,y.hi)]
        candhi=[op2(mul,x,z,RNDU) for x in (self.lo,self.hi) for z in (y.lo,y.hi)]
        return I(sort(candlo,False),sort(candhi,True))
    __rmul__=__mul__
    def reciprocal(self):
        zero=MP(0)
        if cmp(self.lo.ptr(),zero.ptr())<=0 and cmp(self.hi.ptr(),zero.ptr())>=0:
            raise ZeroDivisionError("interval straddles zero")
        one=MP(1)
        return I(op2(div,one,self.hi,RNDD),op2(div,one,self.lo,RNDU))
    def __truediv__(self,y):
        return self*lift(y).reciprocal()
    def __rtruediv__(self,y):
        return lift(y)*self.reciprocal()
    def sqrt(self):
        zero=MP(0)
        if cmp(self.lo.ptr(),zero.ptr())<0: raise ValueError("sqrt negative")
        return I(op1(sqr,self.lo,RNDD),op1(sqr,self.hi,RNDU))
    def erfc(self):
        return I(op1(erfcomp,self.hi,RNDD),op1(erfcomp,self.lo,RNDU))
    def gt0(self):
        return cmp(self.lo.ptr(),MP(0).ptr())>0
    def lt0(self):
        return cmp(self.hi.ptr(),MP(0).ptr())<0
    def decimals(self,digits=59):
        return [self.lo.dec(RNDD,digits), self.hi.dec(RNDU,digits)]
    def approx(self):
        return (self.lo.fl()+self.hi.fl())/2
def lift(x):
    return x if isinstance(x,I) else I.rat(x)
