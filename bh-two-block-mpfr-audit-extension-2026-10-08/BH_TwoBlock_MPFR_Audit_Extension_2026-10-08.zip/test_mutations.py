#!/usr/bin/env python3
"""Adversarial negative controls: tampered witness files must be rejected."""
import argparse,copy,json,tempfile
from pathlib import Path
from verify_certificate import verify

def main(source):
    original=json.loads(Path(source).read_text())
    mutations={}
    def mut(name,f):
        x=copy.deepcopy(original)
        f(x)
        mutations[name]=x
    mut("removed_latent_bin",lambda x:x["rows"].pop(0))
    mut("swapped_alpha_endpoint",lambda x:x["alpha_lo_ratio"].__setitem__(0,999999))
    mut("missing_covering_rectangle",lambda x:x["rows"][0]["intervals"].pop())
    mut("grid_start_does_not_cover",lambda x:x.__setitem__("j_start",4000))
    mut("bad_lower_margin_direction",lambda x:x["rows"][0].__setitem__("lower_margin",x["rows"][0]["lower_margin"][::-1]))
    mut("fabricated_weighted_term",lambda x:x["rows"][0].__setitem__("weighted_coefficient",["1e0","1.01e0"]))
    mut("invalid_overwide_rectangle",lambda x:x["rows"][0].__setitem__("intervals",[[x["j_start"],x["rows"][0]["a"]]]))
    with tempfile.TemporaryDirectory() as td:
        for name,data in mutations.items():
            p=Path(td)/(name+".json")
            p.write_text(json.dumps(data))
            try: verify(p)
            except Exception as exc:
                print("NEGATIVE_CONTROL_REJECTED",name,type(exc).__name__,str(exc)[:140],flush=True)
            else:
                raise AssertionError("INCORRECTLY ACCEPTED CORRUPTED CERTIFICATE: "+name)
    print("NEGATIVE_CONTROLS_PASS count="+str(len(mutations)),flush=True)
if __name__=="__main__":
    pa=argparse.ArgumentParser();pa.add_argument("source")
    a=pa.parse_args()
    main(a.source)
