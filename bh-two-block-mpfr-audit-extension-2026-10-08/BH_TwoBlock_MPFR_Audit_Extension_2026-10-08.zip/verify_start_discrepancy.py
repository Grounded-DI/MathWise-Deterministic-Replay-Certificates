#!/usr/bin/env python3
"""Explicitly verify the 2573/2575 grid-start discrepancy for 1000 bins."""
from fractions import Fraction
from generate_certificate import sign_upper_span,u
from mpfr_interval import I,VERSION,PREC
def run():
    for level in (Fraction(1,100),Fraction(501,50000)):
        assert (u(2573)-I.rat(level)).gt0(), "insufficient grid coverage"
        small=None
        for k in range(-500,500):
            for j in (2573,2574):
                b=sign_upper_span(j,j+1,k,level)
                assert b.lt0(), f"missing strict negativity alpha={level} k={k} j={j}"
                margin=-b
                if small is None or margin.approx()<small.approx():small=margin
        print("START_DISCREPANCY_PASS alpha="+str(level)+" intervals=2000 min_margin="+str(small.decimals(55))+
              " MPFR="+VERSION+" bits="+str(PREC),flush=True)
if __name__=="__main__":run()
